-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 27, 2019 at 08:50 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `organ`
--

-- --------------------------------------------------------

--
-- Table structure for table `blood`
--

CREATE TABLE IF NOT EXISTS `blood` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Blood_group` varchar(20) NOT NULL,
  `Location` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `blood`
--

INSERT INTO `blood` (`id`, `Name`, `Blood_group`, `Location`, `phone`, `filename`) VALUES
(8, 'Shrihari', 'O+ve', 'Bangalore', '8310586252', 'Screenshot (3).png'),
(12, 'Vikas Yadav', 'A-ve', 'Bangalore,hoskote', '9902244368', 'Screenshot (8).png'),
(13, 'Nischai', 'O-ve', 'Malleshwaram', '99042224468', 'Screenshot (3).png'),
(14, 'raj', 'O-ve', 'bangalore', '889906654', 'Screenshot (2).png'),
(15, 'Faizan', 'B+ve', 'kadri', '83232165767', 'bmw_concept_4_2019_4');

-- --------------------------------------------------------

--
-- Table structure for table `eye`
--

CREATE TABLE IF NOT EXISTS `eye` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `father_name` varchar(20) NOT NULL,
  `age` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Email` (`Email`,`mobile`),
  UNIQUE KEY `filename` (`filename`),
  UNIQUE KEY `Email_2` (`Email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `eye`
--

INSERT INTO `eye` (`id`, `name`, `father_name`, `age`, `Email`, `mobile`, `address`, `filename`) VALUES
(1, 'Shrihari', 'M Nagaiah', '20', 'shrihari655@gmail.co', '8310586252', 'Mekhri circle,bangalore', 'Screenshot (5).png'),
(2, 'Mukesh', 'Munirathanam', '20', 'mukesh@gmail.com', '8310586252', 'Hebbal,bangalore', 'Screenshot (8).png'),
(3, 'Vikas', 'Mukesh', '20', 'vikas@gmail.com', '8310586257', 'Hoskote,bangalore', 'Screenshot (2).png');

-- --------------------------------------------------------

--
-- Table structure for table `organs`
--

CREATE TABLE IF NOT EXISTS `organs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `organ` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`phone`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `organs`
--

INSERT INTO `organs` (`id`, `name`, `email`, `organ`, `location`, `phone`, `filename`) VALUES
(1, 'Shrihari', 'Shrihari', 'Liver', 'bangalore', '8310586252', 'Screenshot (7).png'),
(2, 'mukesh', 'mukesh@gmil.com', 'Pancreas', 'bangalore', '8236542436', 'Screenshot (4).png');

-- --------------------------------------------------------

--
-- Table structure for table `stem`
--

CREATE TABLE IF NOT EXISTS `stem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `cells` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `stem`
--

INSERT INTO `stem` (`id`, `name`, `email`, `cells`, `location`, `phone`, `filename`) VALUES
(1, 'Shrihari', 'shrihari@gmail.com', 'Non-embryonic (adult', 'bangalore', '8310586252', 'Screenshot (4).png'),
(2, 'Mukesh M kumar', 'mukesh@gmail.com', 'Embryonic stem cells', 'hebbal bridge', '9902242268', 'Screenshot (5).png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `age` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `organs` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `Name`, `age`, `gender`, `Email`, `phone`, `organs`, `location`, `filename`) VALUES
(1, 'Mukesh Kumar', '20', 'Male', 'mukeshwara@gmail.com', '748383549', 'Blood', 'Hebbal', ''),
(2, 'Vikas', '20', 'Male', 'vikas@gmail.com', '8306576789', 'Blood', 'Hoskote', ''),
(3, 'Nischai', '20', 'male', 'nischai@gmail.com', '973566565', 'blood', 'malleshwaram', '');
